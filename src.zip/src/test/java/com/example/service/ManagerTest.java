package com.example.service;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.example.EmailUtility;
import com.example.controller.AuthenticationController;
import com.example.controller.UserController;
import com.example.entity.Batches;
import com.example.entity.Comments;
import com.example.entity.EnrollmentStatus;
import com.example.entity.Offers;
import com.example.entity.Users;
import com.example.exception.SeatNotAvailable;
import com.example.repository.BatchesRepository;
import com.example.repository.CommentsRepository;
import com.example.repository.EnrollmentRepository;
import com.example.repository.LikesRepository;
import com.example.repository.OffersRepository;
import com.example.repository.SportsRepository;
import com.example.repository.UsersRepository;

class ManagerTest {
	@InjectMocks
	private ManagerServiceImpl managerServiceImpl;
	@Mock
	private AuthenticationController authController;
	@Mock
	private  UserController userController;
	
	@Mock
	private LikesRepository likesRepository;
	
	@Mock
	private CommentsRepository commentsRepository;
	
	@Mock
	private OffersRepository offerRespository;
	
	@Mock
	private BatchesRepository batchRepository;
	
	@Mock
	private SportsRepository sportRepository;
	
	@Mock
	private EnrollmentRepository enrollmentRepository;
	
	@Mock
	private EmailUtility emailUtility;
	
	@Mock
	private UsersRepository userrepository;


	String otp;

	Offers offer = new Offers(10, "Winter", 3, 12, 12);
	Users user = new Users(10, "snehal", "snehalshe@cybage.com", "snehal", "7387833055", "pune", "CUSTOMER", "B+", true,
			0);
	Comments comment = new Comments(5, offer, user, "this is affordable offer thank you.");
	
	// Batches batch = new Batches(222,"AFTERNOON",LocalTime.of(11, 00, 00),LocalTime.of(14, 00, 00),50,50);
	@BeforeEach
	void setup() throws Exception{
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	void testGetEnrollmentData() {
		assertNotNull(managerServiceImpl.getEnrollmentData());
	}

	@Test
	void testGetEnrollmentListByStatusOfEnrollment() {
		
		assertNotNull(managerServiceImpl.getEnrollmentListByStatusOfEnrollment(EnrollmentStatus.PENDING));
	}

	@Test
	void testGetPendingEnrollmentList() {
		assertNotNull(managerServiceImpl.getEnrollmentListByStatusOfEnrollment(EnrollmentStatus.PENDING));
	}

	@Test
	void testGetApprovedEnrollmentList() {
		assertNotNull(managerServiceImpl.getEnrollmentListByStatusOfEnrollment(EnrollmentStatus.APPROVED));

	}

	@Test
	void testGetRenewEnrollmentList() {
		assertNotNull(managerServiceImpl.getEnrollmentListByStatusOfEnrollment(EnrollmentStatus.RENEW));

	}

//	@Test
//	void testUpdateBatchSize() throws SeatNotAvailable {
//		int batchSize =batch.getBatchSize();
//		System.out.println(batch.getBatchId());
//		managerServiceImpl.updateBatchSize(batch.getBatchId());
//		System.out.println( batch.getBatchRemainingSeats());
//		assertEquals(batchSize-1, batch.getBatchRemainingSeats());
//	}

//	@Test
//	void testApproveEnrollment() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testRejectEnrollment() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testRenewEnrollment() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testGetBatches() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testGetAllOffers() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testGetOffer() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testAddOffer() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testGetEnrollmentByOfferId() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testDeleteOffer() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testUpdateOfferById() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testUpdatePassword() {
//		fail("Not yet implemented");
//	}

}
