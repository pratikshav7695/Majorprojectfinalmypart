
package com.example.service;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Date;
import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import com.example.EmailUtility;
import com.example.controller.AuthenticationController;
import com.example.controller.UserController;
import com.example.dto.ForgetPasswordDto;
import com.example.dto.UsersDto;
import com.example.entity.Comments;
import com.example.entity.Enrollment;
import com.example.entity.EnrollmentStatus;
import com.example.entity.LikeId;
import com.example.entity.Likes;
import com.example.entity.Offers;
import com.example.entity.Users;
import com.example.repository.BatchesRepository;
import com.example.repository.CommentsRepository;
import com.example.repository.EnrollmentRepository;
import com.example.repository.LikesRepository;
import com.example.repository.OffersRepository;
import com.example.repository.SportsRepository;
import com.example.repository.UsersRepository;


class UserTest{


	@InjectMocks
	private UserServiceImpl userService;
	@Mock
	private AuthenticationController authController;
	@Mock
	private  UserController userController;
	
	@Mock
	private LikesRepository likesRepository;
	
	@Mock
	private CommentsRepository commentsRepository;
	
	@Mock
	private OffersRepository offerRespository;
	
	@Mock
	private BatchesRepository batchRepository;
	
	@Mock
	private SportsRepository sportRepository;
	
	@Mock
	private EnrollmentRepository enrollmentRepository;
	
	@Mock
	private EmailUtility emailUtility;
	
	@Mock
	private UsersRepository userrepository;


	String otp;

	Offers offer = new Offers(10, "Winter", 3, 12, 12);
	Users user = new Users(10, "snehal", "snehalshe@cybage.com", "snehal", "7387833055", "pune", "CUSTOMER", "B+", true,
			0);
	Comments comment = new Comments(5, offer, user, "this is affordable offer thank you.");

	
	@BeforeEach
	void setup() throws Exception{
		MockitoAnnotations.initMocks(this);
	}
	
	
	//
//	@Test
//	void testEmaiVerification() {
//		assertEquals(ResponseEntity.status(HttpStatus.OK).body(otp),
//				userController.emailVerification("snehalshevade07@gmail.com"));
//	}

	@Test
	void testRegisterNewUser() {
		UsersDto user = new UsersDto("snehal", "snehalshevade07@gmail.com", "snehal", "7387833055", "pune", "CUSTOMER",
				"B+", true, 0);
		assertNotNull(userService.registerNewUser(user));
	}

	@Test
	void testGetAllBatches() {
		assertNotNull(userService.getAllBatches());
	}

	@Test
	void testGetAllSports() {
		assertNotNull(userService.getAllSports());
	}

	@Test
	void testGetAllOffers() {
		assertNotNull(userService.getAllOffers());
	}

//	@Test
//	void testUpdatePassword() {
//		LoginUser user = new LoginUser();
//		user.setUsername("snehal");
//		user.setPassword("snehal");
//		authController.register(user);
//      }

	@Test
	void testGetAllEnrollments() {
		assertNotNull(userService.getAllEnrollments("snehal"));
	}

	@Test
	void testRenewEnrollment() {
		Enrollment enrollment = new Enrollment(3, 1, 1, 1, 1,Date.valueOf(LocalDate.parse("2020-04-02")),
				Date.valueOf(LocalDate.parse("2020-12-31")), 5000.0, EnrollmentStatus.PENDING);
		System.out.println(enrollment.getEnrollmentEndDate());
		System.out.println(enrollment);
		System.out.println("status::"+enrollment.getEnrollmentStatus());
		assertNotNull(userService.renewEnrollment(3, enrollment));
	}

	@Test
	void testAddLikeToOffer() {
		LikeId likeId = new LikeId(1, 1);
		Likes like = new Likes(likeId, true);
		assertNotNull(userService.addLikeToOffer(like));
	}

	@Test
	void testAddComment() {
		assertNotNull(userService.addComment(comment));
	}

	@Test
	void testGetAllLikes() {
		assertNotNull(this.likesRepository.findAll());
	}

	@Test
	void testGetAllComments() {
		assertNotNull(userService.getAllComments());
	}

	@Test
	void testFindByUserName() {
		assertNotNull(userService.findByUserName("snehal"));
	}

	@Test
	void testFindByUserEmail() {
		assertNotNull(userService.findByUserEmail("snehalshevade07@gmail.com"));
	}

	@Test
	void testSendOTP() {
		assertNotNull(userService.sendOTP("snehalshevade07@gmail.com"));
	}

	@Test
	void testSetNewPassword() {
		ForgetPasswordDto forgetPasswordDto = new ForgetPasswordDto("snehalshevade07@gmail.com", "snehal@123");
		assertNotNull(userService.setNewPassword(forgetPasswordDto));
	}

	@Test
	void testEditComment() {
		comment.setComments("Edited Comment");
		assertNotNull(userService.editComment(comment));
	}

}
