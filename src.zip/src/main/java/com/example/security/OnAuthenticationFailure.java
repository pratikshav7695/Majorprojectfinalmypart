package com.example.security;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.security.authentication.event.AuthenticationFailureBadCredentialsEvent;
import org.springframework.stereotype.Component;
import com.example.entity.Users;
import com.example.repository.UsersRepository;

@Component
public class OnAuthenticationFailure {

	@Autowired
	UsersRepository usersRepository;

	@EventListener
	public void onAuthenticationFailure(AuthenticationFailureBadCredentialsEvent event) {
		String email =(String)event.getAuthentication().getPrincipal();

		Users user = usersRepository.findByUserName(email);
		if(user !=null) {
			if(user.getFailedLoginCounts()<3) {
				user.setFailedLoginCounts(user.getFailedLoginCounts()+1);	
				if(user.getFailedLoginCounts()==3) {					
					user.setActive(false);
				}
			}			
			usersRepository.save(user);
		}
	}
}