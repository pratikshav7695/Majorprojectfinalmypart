package com.example.report;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;
import com.example.dto.EnrollmentDto;
import com.example.entity.Batches;
import com.example.entity.Sports;
import com.example.repository.BatchesRepository;
import com.example.repository.SportsRepository;
import com.example.service.ManagerServiceImpl;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;


@Service
public class ReportService {

	@Autowired
	private ManagerServiceImpl managerServiceImpl;
		
	@Autowired
	private BatchesRepository batchesRepository;
	
	@Autowired
	private SportsRepository sportsRepository;

	private String path="C:\\Users\\Administrator\\Desktop\\new\\JavaMajorProject-G2";
	public String exportReportForEnrollment(String reportFormat) throws FileNotFoundException,JRException {
		List<EnrollmentDto> enrollments=managerServiceImpl.getEnrollmentData();
		//load and compile
		String fileLocation="classpath:enrollment.jrxml";
		File file=ResourceUtils.getFile( fileLocation);
		JasperReport jasperReport=JasperCompileManager.compileReport(file.getAbsolutePath());
		JRBeanCollectionDataSource datasource= new JRBeanCollectionDataSource(enrollments);
		Map<String,Object> parameters=new HashMap<>();
		parameters.put("createdBy","Group 2");
		JasperPrint jasperPrint=JasperFillManager.fillReport(jasperReport, parameters, datasource);

		if(reportFormat.equalsIgnoreCase("html")) {
			JasperExportManager.exportReportToHtmlFile(jasperPrint,path + "\\enrollment.html");
		}
		if(reportFormat.equalsIgnoreCase("pdf")) {
			JasperExportManager.exportReportToHtmlFile(jasperPrint,path + "\\enrollment.pdf");
		}

		return "Enrollment Report generated in path : " +path;		
	}
	
	public String exportReportForBatches(String reportFormat) throws FileNotFoundException,JRException {
		List<Batches> batches=batchesRepository.findAll();
		//load and compile
		String fileLocation="classpath:batch.jrxml";
		File file=ResourceUtils.getFile( fileLocation);
		JasperReport jasperReport=JasperCompileManager.compileReport(file.getAbsolutePath());
		JRBeanCollectionDataSource datasource= new JRBeanCollectionDataSource(batches);
		Map<String,Object> parameters=new HashMap<>();
		parameters.put("createdBy","Group 2");
		JasperPrint jasperPrint=JasperFillManager.fillReport(jasperReport, parameters, datasource);

		if(reportFormat.equalsIgnoreCase("html")) {
			JasperExportManager.exportReportToHtmlFile(jasperPrint,path + "\\batch.html");
		}
		if(reportFormat.equalsIgnoreCase("pdf")) {
			JasperExportManager.exportReportToPdfFile(jasperPrint,path + "\\batch.pdf");
		}

		return "Batch Report generated in path : " +path;		
	}
	
	public String exportReportForSports(String reportFormat) throws FileNotFoundException,JRException {
		List<Sports> batches=sportsRepository.findAll();
		//load and compile
		String fileLocation="classpath:sports.jrxml";
		File file=ResourceUtils.getFile( fileLocation);
		JasperReport jasperReport=JasperCompileManager.compileReport(file.getAbsolutePath());
		JRBeanCollectionDataSource datasource= new JRBeanCollectionDataSource(batches);
		Map<String,Object> parameters=new HashMap<>();
		parameters.put("createdBy","Group 2");
		JasperPrint jasperPrint=JasperFillManager.fillReport(jasperReport, parameters, datasource);

		if(reportFormat.equalsIgnoreCase("html")) {
			JasperExportManager.exportReportToHtmlFile(jasperPrint,path + "\\sports.html");
		}
		if(reportFormat.equalsIgnoreCase("pdf")) {
			JasperExportManager.exportReportToPdfFile(jasperPrint,path + "\\sports.pdf");
		}

		return "Sport Report generated in path : " +path;		
	}

	
}
