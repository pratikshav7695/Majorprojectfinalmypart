package com.example.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.dto.EnrollmentDto;
import com.example.dto.PasswordUpdate;
import com.example.entity.Offers;
import com.example.entity.Users;
import com.example.exception.SeatNotAvailable;
import com.example.service.ManagerServiceI;

@RestController
@RequestMapping("/manager")
public class ManagerController {

	@Autowired(required = true)
	ManagerServiceI managerService;	

	Users user;

	//getting list of all the members who have applied for different enrollment
	@PreAuthorize("hasRole('ROLE_MANAGER')")
	@GetMapping(value="/all-enrollment-data-list")
	public ResponseEntity<?> getEnrollmentData()
	{
		List<EnrollmentDto> enrollmentData = managerService.getEnrollmentData();
		if (enrollmentData.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Enrollments not found in database");
		} else
			return ResponseEntity.status(HttpStatus.FOUND).body(enrollmentData);
	}


	//getting list of all the members who have applied for enrollment having pending status
	@PreAuthorize("hasRole('ROLE_MANAGER')")
	@GetMapping(value="/all-pending-status-enrollments-list")
	public ResponseEntity<?> getPendingEnrollmentList()
	{	
		List<EnrollmentDto> enrollmentData = managerService.getPendingEnrollmentList();
		if (enrollmentData.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NO_CONTENT).body("No pending enrollments present in database");
		} else
			return ResponseEntity.status(HttpStatus.FOUND).body(enrollmentData);
	}

	//getting list of all the members who have applied for renewing enrollment
	@PreAuthorize("hasRole('ROLE_MANAGER')")
	@GetMapping(value="/all-renew-status-enrollments-list")
	public ResponseEntity<?> getRenewStatusEnrollmentList()
	{
		List<EnrollmentDto> enrollmentData = managerService.getRenewEnrollmentList();
		if (enrollmentData.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NO_CONTENT).body("No renew-status enrollments present in database");
		}
		else
			return ResponseEntity.status(HttpStatus.FOUND).body(enrollmentData);			
	}

	//getting list of all approved status enrollments
	@PreAuthorize("hasRole('ROLE_MANAGER')")
	@GetMapping(value="/all-approved-status-enrollments-list")
	public ResponseEntity<?> getApprovedEnrollmentList()
	{
		List<EnrollmentDto> enrollmentData = managerService.getApprovedEnrollmentList();
		if (enrollmentData.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NO_CONTENT).body("No approved enrollments present in database");
		}
		else
			return ResponseEntity.status(HttpStatus.FOUND).body(enrollmentData);	
	}

	//approve enrollment
	@PreAuthorize("hasRole('ROLE_MANAGER')")
	@PutMapping(value="/approve-enrollment/{id}")
	public ResponseEntity<?> approveEnrollment(@PathVariable(value = "id") int enrollmentId) throws SeatNotAvailable
	{		
		if( managerService.approveEnrollment(enrollmentId)!=null)
		{
			return ResponseEntity.status(HttpStatus.OK).body("Approved Successfully");
		}
		else
			return  ResponseEntity.status(HttpStatus.NOT_FOUND).body("Couldnt complete the approve request"); 	  
	}

	//reject enrollment 
	@PreAuthorize("hasRole('ROLE_MANAGER')")
	@PutMapping(value="/reject-enrollment/{id}")
	public ResponseEntity<?> rejectEnrollment(@PathVariable(value = "id") int enrollmentId)
	{
		if( managerService.rejectEnrollment(enrollmentId)!=null)
		{
			return ResponseEntity.status(HttpStatus.OK).body("Rejected Successfully");
		}
		else
			return  ResponseEntity.status(HttpStatus.NOT_FOUND).body("Couldnt complete the reject request"); 	  
	}

	//Renew enrollment 
	@PreAuthorize("hasRole('ROLE_MANAGER')")
	@PutMapping(value="/renew-enrollment/{id}")
	public ResponseEntity<?> renewEnrollment(@PathVariable(value = "id") int enrollmentId) throws SeatNotAvailable
	{
		if( managerService.renewEnrollment(enrollmentId)!=null)
		{
			return ResponseEntity.status(HttpStatus.OK).body("Renewed enrollment Successfully");
		}
		else
			return  ResponseEntity.status(HttpStatus.NOT_FOUND).body("Couldnt complete the renew request"); 	  
	}



	//Getting the list of all the offers that are available
	@PreAuthorize("hasRole('ROLE_MANAGER')")
	@GetMapping(value = "/get-all-offers")
	public ResponseEntity<?> getOffers(){		
		List<Offers> listOfAllOffers =  managerService.getAllOffers();
		if(listOfAllOffers.isEmpty()) {
			return  ResponseEntity
					.status(HttpStatus.NOT_FOUND)
					.body("No Offers found in Database");
		}else 
		{
			return  ResponseEntity.status(HttpStatus.OK).body(listOfAllOffers); 	  
		}
	}
	//Getting a single offer using its id
	@PreAuthorize("hasRole('ROLE_MANAGER')")
	@GetMapping("/get-offer/{offerId}")
	public ResponseEntity<?> getOffer(@PathVariable int offerId){

		if(managerService.getOffer(offerId).isEmpty()) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No offer with offer id "+offerId+" found");
		}else {
			return ResponseEntity.status(HttpStatus.FOUND).body(managerService.getOffer(offerId));
		}
	}
	//Creating a new offer
	@PreAuthorize("hasRole('ROLE_MANAGER')")
	@PostMapping("/add-new-offer")
	public ResponseEntity<?> addOffer(@RequestBody Offers offer){
		Offers newOffer=managerService.addOffer(offer);
		if(newOffer==null) {
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body("Cannot create a new offer");
		}else {
			return ResponseEntity.status(HttpStatus.CREATED).body(newOffer);
		}
	}
	//Deleting an existing offer
	@PreAuthorize("hasRole('ROLE_MANAGER')")
	@DeleteMapping("/delete-offer/{offerId}")
	public ResponseEntity<?> deleteManagerById(@PathVariable int offerId) {
		if(managerService.deleteOffer(offerId)) {
			return ResponseEntity.status(HttpStatus.OK).body("Offer deleted with Offer Id: " + offerId);
		}else {
			return ResponseEntity.status(HttpStatus.CONFLICT).body("Offer : "+offerId+" cannot be deleted as it is being used");
		}
	}
	//Updating an existing offer
	@PreAuthorize("hasRole('ROLE_MANAGER')")
	@PutMapping("/update-offer/{offerId}")
	public ResponseEntity<?> updateOffer(@RequestBody Offers offer, @PathVariable int offerId){

		return ResponseEntity.status(HttpStatus.OK).body(managerService.updateOfferById(offer, offerId));
	}
	//Updating the password of Manager
	@PreAuthorize("hasRole('ROLE_MANAGER')")
	@PostMapping("/update-password")
	public ResponseEntity<?> updatePassword(@RequestBody PasswordUpdate passwordUpdate) {
		user = managerService.updatePassword(SecurityContextHolder.getContext().getAuthentication(),
				passwordUpdate.getNewPassword(), passwordUpdate.getOldPassword());
		if (user != null) {
			return ResponseEntity.status(HttpStatus.OK).body("Password Update Succssesful");
		} else {
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body("Something went wrong");
		}
	}
}
