package com.example.service;

import java.util.List;

import org.springframework.security.core.Authentication;
import com.example.dto.EnrollmentDto;
import com.example.dto.ForgetPasswordDto;
import com.example.dto.UsersDto;
import com.example.entity.Batches;
import com.example.entity.Comments;
import com.example.entity.Enrollment;
import com.example.entity.Likes;
import com.example.entity.OffersDTO;
import com.example.entity.Sports;
import com.example.entity.Users;
import com.example.exception.BatchTimeConflict;
import com.example.exception.InvalidDateException;
import com.example.exception.SeatNotAvailable;

public interface IUserService {

	public Users findByUserName(String userName);

	public Users findByUserEmail(String userEmail);

	// public Users findByUserPhone(String userPhone);
	public Users registerNewUser(UsersDto newUser);
	
	public Users getUserProfile(String userName);

	public List<Batches> getAllBatches();

	public List<Sports> getAllSports();

	public List<OffersDTO> getAllOffers();

	public List<Enrollment> getAllEnrollments(String userName);

	public List<Likes> getAllLikes();

	public List<Comments> getAllComments();

	public String renewEnrollment(int id, Enrollment enrollment);

	public Comments editComment(Comments comment);
	
	public String deleteComment(Comments comment,int id);

	public String sendOTP(String email);

	public int setNewPassword(ForgetPasswordDto forgetPasswordDto);


	public String addLikeToOffer(Likes like);
	
	public void updateLikeCountPlus(int offerId);
	
	public void updateLikeCountMinus(int offerId);

	public Comments addComment(Comments comment);

	Users updatePassword(Authentication auth, String newPassword, String oldPassword);
	
	public String enrollCustomer( EnrollmentDto enrollment,int userId) throws BatchTimeConflict,SeatNotAvailable, InvalidDateException;
	
	public List<Enrollment> getUserEnrollments(int userId);
  
}
