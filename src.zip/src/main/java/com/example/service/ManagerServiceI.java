package com.example.service;

import java.util.List;
import java.util.Optional;

import org.springframework.security.core.Authentication;

import com.example.dto.EnrollmentDto;
import com.example.entity.Batches;
import com.example.entity.Enrollment;
import com.example.entity.Offers;
import com.example.entity.Users;
import com.example.exception.SeatNotAvailable;

public interface ManagerServiceI {
	
	List<EnrollmentDto> getEnrollmentData();	
	List<EnrollmentDto> getPendingEnrollmentList();
	List<EnrollmentDto> getApprovedEnrollmentList();
	List<EnrollmentDto> getRenewEnrollmentList();
	Batches updateBatchSize(int batchId) throws Exception;
	Enrollment approveEnrollment(int enrollmentId) throws SeatNotAvailable;
	Enrollment rejectEnrollment(int enrollmentId);
	Enrollment renewEnrollment(int enrollmentId) throws SeatNotAvailable;
	List<Batches> getBatches();
	public List<Offers> getAllOffers();
	public Optional<Offers> getOffer(int offerId);
	public Offers addOffer(Offers offer);
	public boolean deleteOffer(int offerId);
	public String updateOfferById(Offers offer,int offerId);
	public List<Enrollment> getEnrollmentByOfferId(int offerId);
	Users updatePassword(Authentication auth, String newPassword, String oldPassword);
	
	public Optional<Batches> getBatch(int batchId);
	public List<Batches> getAllBatches();
	public Batches addBatch(Batches batch);
	public Boolean deleteBatch(int batchId);
	public String updateBatch(Batches batch, int batchId);
	public List<Enrollment> getEnrollmentByBatchId(int batchId);
}
