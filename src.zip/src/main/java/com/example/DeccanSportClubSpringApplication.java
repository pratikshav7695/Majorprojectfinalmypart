package com.example;

import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import com.example.entity.Batches;
import com.example.entity.Comments;
import com.example.entity.LikeId;
import com.example.entity.Likes;
import com.example.entity.Offers;
import com.example.entity.Sports;
import com.example.entity.Users;
import com.example.repository.BatchesRepository;
import com.example.repository.CommentsRepository;
import com.example.repository.LikesRepository;
import com.example.repository.OffersRepository;
import com.example.repository.SportsRepository;
import com.example.repository.UsersRepository;

@SpringBootApplication(scanBasePackages = { "com.example", "com.example.repository", "com.example.entity",
		"com.example.controller", "com.example.service" })
@EnableJpaRepositories
@Configuration
public class DeccanSportClubSpringApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(DeccanSportClubSpringApplication.class, args);
	}

	@Autowired
	UsersRepository ur;
    @Autowired
	BatchesRepository br;
	@Autowired
	SportsRepository sr;
	@Autowired
	OffersRepository or;
	@Autowired
	LikesRepository lr;
	@Autowired
	CommentsRepository cr;

	@Override
	public void run(String... args) throws Exception {
		

		Users user1 = new Users("Snehal", "snehalshe@cyabge.com", new BCryptPasswordEncoder().encode("snehal"),
				"9545777517", "Cybage1", "CUSTOMER", "O+", true, 0);
		ur.save(user1);
		Users user2 = new Users("Shubham", "shubhamdes@cyabge.com", new BCryptPasswordEncoder().encode("shubham"),
				"9545777514", "Cybage2", "ADMIN", "O+", true, 0);
		ur.save(user2);
		Users user3 = new Users("Tejashri", "tejashrip@cyabge.com", new BCryptPasswordEncoder().encode("tejashri"),
				"9545777511", "Cybage3", "MANAGER", "O+", true, 0);
		ur.save(user3);
		
		Users user4 = new Users("Pratiksha", "pratikshav@cyabge.com", new BCryptPasswordEncoder().encode("pratiksha"),
				"9545777514", "Cybage2", "ADMIN", "O+", true, 0);
		ur.save(user4);
		Batches batch1 = new Batches(1, "MORNING", LocalTime.of(06, 00, 00), LocalTime.of(10, 00, 00), 50, 50,
				Date.valueOf(LocalDate.parse("2020-07-04")), "Tejashri");
		br.save(batch1);
		Batches batch2 = new Batches(2, "AFTERNOON", LocalTime.of(11, 00, 00), LocalTime.of(14, 00, 00), 50, 50,
				Date.valueOf(LocalDate.parse("2020-07-04")), "Tejashri");
		br.save(batch2);
		Batches batch3 = new Batches(3, "EVENING", LocalTime.of(17, 00, 00), LocalTime.of(20, 00, 00), 50, 50,
				Date.valueOf(LocalDate.parse("2020-07-04")), "Tejashri");
		br.save(batch3); 
		
		
		
		
		  Sports sport1 = new Sports("CRICKET", 5000,
		  Date.valueOf(LocalDate.parse("2020-07-04")), "Tejashri"); sr.save(sport1); Sports
		  sport2 = new Sports("FOOTBALL", 7000,
		  Date.valueOf(LocalDate.parse("2020-07-04")), "Tejashri"); sr.save(sport2); Sports
		  sport3 = new Sports("GOLF", 15000,
		  Date.valueOf(LocalDate.parse("2020-07-04")), "Tejashri"); sr.save(sport3);
		 
		  
		  Offers offer1 = new Offers(1, "SILVER", 3, 10, 0); or.save(offer1); Offers
		  offer2 = new Offers(2, "GOLD", 6, 15, 0); or.save(offer2); Offers offer3 =
		  new Offers(3, "PLATINUM", 12, 10, 0); or.save(offer3); Offers offer4 = new
		  Offers(4, "GENERAL", 10, 0);
          or.save(offer4);
		 
		
		
	}
}
