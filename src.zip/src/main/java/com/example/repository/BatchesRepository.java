package com.example.repository;




import org.springframework.data.jpa.repository.JpaRepository;
import java.sql.Date;
import java.time.LocalTime;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.example.entity.Batches;


@Repository
public interface BatchesRepository extends JpaRepository<Batches, Integer>{

	@Transactional
	@Modifying
	@Query("UPDATE Batches b SET b.batchId =?1,b.batchName=?2,b.batchStartTime=?3,b.batchEndTime=?4,b.batchSize=?5,b.batchRemainingSeats=?6,b.batchAddDate=?7,b.managerName=?8 where batchId=?9 ") 
	public void updateBatchById(int batchId,String batchName,LocalTime batchStartTime,LocalTime batchEndTime, int batchSize,int batchRemainingSeats,Date batchAddDate,String managerName,int batchId1);  
	
	 @Query("Select b from Batches b where b.batchName =:batchName ")       // using @query
	 Batches findByBatchName(String batchName);

	

	
}
