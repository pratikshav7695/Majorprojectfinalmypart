package com.example.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.entity.LikeId;
import com.example.entity.Likes;

public interface LikesRepository extends JpaRepository<Likes, LikeId>{
	boolean existsById(Optional<Likes> findById);
}
