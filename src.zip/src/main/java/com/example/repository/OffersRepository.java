package com.example.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.example.entity.Offers;
import com.example.entity.OffersDTO;



@Repository
public interface OffersRepository extends JpaRepository<Offers, Integer>{
	public Offers findByofferName(String offername);
	//to get offer and like's table data
	@Query(value = "select new com.example.entity.OffersDTO(o.offerId,o.offerName,o.offerDuration,o.offerDiscount,o.likesOnOffer,l.isLiked) from Offers o join Likes l on o.offerId=l.id.offerId",nativeQuery = false)
	public List<OffersDTO> getOffers();

	@Transactional
	@Modifying

	@Query(value = "update Offers set likesOnOffer=likesOnOffer+1 where offerId=:offerId")
	public void updaetLikeCountPlus(@Param("offerId")int offerId);
	
	@Transactional
	@Modifying
	@Query(value = "update Offers set likesOnOffer=likesOnOffer-1 where offerId=:offerId")
	public void updaetLikeCountMinus(@Param("offerId")int offerId);


	@Query("UPDATE Offers o SET o.offerId =?1,o.offerName=?2,o.offerDuration=?3,o.offerDiscount=?4,o.likesOnOffer=?5 where offerId=?6") 
	public void updateOfferById(int offerId,String offerName,int offerDuration,int offerDiscount ,int likesOnOffer,int offerId1);

}
