package com.example.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.entity.Sports;

@Repository
public interface SportsRepository  extends JpaRepository<Sports, Integer>{

	Optional<Sports> findBySportName(String sportName);

}
