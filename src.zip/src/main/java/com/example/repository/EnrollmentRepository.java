package com.example.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.entity.Enrollment;
import com.example.entity.EnrollmentStatus;
import com.example.entity.Users;

@Repository
public interface EnrollmentRepository extends JpaRepository<Enrollment, Integer> {

	public Users findByUserId(int userId);

	@Query("Select e from Enrollment e where e.enrollmentStatus =:enrollmentStatus ") // using @query
	List<Enrollment> findByEnrollmentStatus(EnrollmentStatus enrollmentStatus);

	List<Enrollment> findByEnrollmentStatus(String enrollmentStatus);

	@Query("select e from Enrollment e where e.userId.userName=:username")
	public List<Enrollment> listofEnrollmentsOfUser(String username);

	@Query("Select e from Enrollment e where e.userId =:userId ") // using @query
	List<Enrollment> findUserEnrollmentsByUserId(Users userId);

	@Query(value = "SELECT * FROM Enrollment e WHERE e.fk_offer_id = ?1", nativeQuery = true)

	public List<Enrollment> getEnrollmentByOfferId(int offerId);

	@Query(value = "SELECT * FROM Enrollment e WHERE e.fk_batch_id = ?1", nativeQuery = true)
	public List<Enrollment> getEnrollmentByBatchId(int batchId);
	

}
