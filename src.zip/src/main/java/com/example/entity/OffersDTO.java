package com.example.entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class OffersDTO {
	private int offerId;
	private String offerName;
	private int offerDuration;
	private int offerDiscount;
	private int likesOnOffer;
	@Getter@Setter
	private boolean isLiked;
	

	public OffersDTO() {
		super();
		
	}

	public OffersDTO(int offerId, String offerName, int offerDuration, int offerDiscount, int likesOnOffer) {
		super();
		this.offerId = offerId;
		this.offerName = offerName;
		this.offerDuration = offerDuration;
		this.offerDiscount = offerDiscount;
		this.likesOnOffer = likesOnOffer;
	}
	
	

	public OffersDTO(int offerId, String offerName, int offerDuration, int offerDiscount, int likesOnOffer,
			boolean isLiked) {
		super();
		this.offerId = offerId;
		this.offerName = offerName;
		this.offerDuration = offerDuration;
		this.offerDiscount = offerDiscount;
		this.likesOnOffer = likesOnOffer;
		this.isLiked = isLiked;
	}

	public int getOfferId() {
		return offerId;
	}

	public void setOfferId(int offerId) {
		this.offerId = offerId;
	}

	public String getOfferName() {
		return offerName;
	}

	public void setOfferName(String offerName) {
		this.offerName = offerName;
	}

	public int getOfferDuration() {
		return offerDuration;
	}

	public void setOfferDuration(int offerDuration) {
		this.offerDuration = offerDuration;
	}

	public int getOfferDiscount() {
		return offerDiscount;
	}

	public void setOfferDiscount(int offerDiscount) {
		this.offerDiscount = offerDiscount;
	}

	public int getLikesOnOffer() {
		return likesOnOffer;
	}

	public void setLikesOnOffer(int likesOnOffer) {
		this.likesOnOffer = likesOnOffer;
	}
	
	

	public boolean isLiked() {
		return isLiked;
	}

	public void setLiked(boolean isLiked) {
		this.isLiked = isLiked;
	}

	@Override
	public String toString() {
		return "OffersDTO [offerId=" + offerId + ", offerName=" + offerName + ", offerDuration=" + offerDuration
				+ ", offerDiscount=" + offerDiscount + ", likesOnOffer=" + likesOnOffer + "]";
	}

}
