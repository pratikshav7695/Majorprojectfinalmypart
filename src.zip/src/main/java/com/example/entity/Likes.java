package com.example.entity;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Entity
public class Likes {

	@EmbeddedId
	private LikeId id;

	@NotNull
	@Column(name = "isLiked")
	@Getter
	@Setter
	private boolean isLiked;

	public Likes() {
		super();

	}

	public Likes(LikeId likeId, @NotNull boolean isLiked) {
		super();
		this.id = likeId;
		this.isLiked = isLiked;
	}

	public LikeId getLikeId() {
		return id;
	}

	public void setLikeId(LikeId likeId) {
		this.id = likeId;
	}

	public boolean isLiked() {
		return isLiked;
	}

	public void setLiked(boolean isLiked) {
		this.isLiked = isLiked;
	}

	@Override
	public String toString() {
		return "Likes [likeId=" + id + ", isLiked=" + isLiked + "]";
	}

	
}
