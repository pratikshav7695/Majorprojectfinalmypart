package com.example.entity;

public enum EnrollmentStatus {
     PENDING,APPROVED,REJECTED,RENEW, RENEWED
}
