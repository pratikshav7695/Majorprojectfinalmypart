package com.example.exception;

public class NoContentFound extends Exception{

	public NoContentFound(String msg) {
		super(msg);
	}
}
