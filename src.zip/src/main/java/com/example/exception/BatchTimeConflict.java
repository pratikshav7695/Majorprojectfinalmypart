package com.example.exception;

public class BatchTimeConflict extends Exception {

	public BatchTimeConflict(String msg) {
		super(msg);
	}

}
