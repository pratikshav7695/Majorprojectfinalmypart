package com.example.exception;

public class UserException extends Exception {

	public UserException(String msg) {
		super(msg);
	}

}
