package com.example.exception;

public class MessagingException extends Exception {

	public MessagingException(String msg) {
		super(msg);
	}
}
