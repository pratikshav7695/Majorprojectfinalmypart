package com.example.exception;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ExceptionController {
	private String errMsg = "Could not process request:";
	public static final Logger logger = LogManager.getLogger(ExceptionController.class);

	@ExceptionHandler(UserException.class)
	@ResponseStatus(code = HttpStatus.INTERNAL_SERVER_ERROR)
	public String forInternalError(UserException ue) {
		logger.error(errMsg, ue.getMessage());
		return errMsg + ue.getMessage();
	}
	
	
	@ExceptionHandler(NoContentFound.class)
	@ResponseStatus(code = HttpStatus.NO_CONTENT)
	public String forNoContent(UserException ue) {
		logger.error(errMsg, ue.getMessage());
		return errMsg + ue.getMessage();
	}

	@ExceptionHandler(MessagingException.class)
	@ResponseStatus(code = HttpStatus.INTERNAL_SERVER_ERROR)
	public String messagingException(Exception ue) {
		logger.error(errMsg, ue.getMessage());
		return errMsg + ue.getMessage();
	}
	

	@ExceptionHandler(SeatNotAvailable.class)
	@ResponseStatus(code = HttpStatus.GONE)
	public String seatNotAvailableException(Exception ue) {
		logger.error(errMsg, ue.getMessage());
		return errMsg + ue.getMessage();
	}
	

	@ExceptionHandler(BatchTimeConflict.class)
	@ResponseStatus(code = HttpStatus.ALREADY_REPORTED)
	public String batchTimingConflictException(Exception ue) {
		logger.error(errMsg, ue.getMessage());
		return errMsg + ue.getMessage();
	}
	

	@ExceptionHandler(InvalidDateException.class)
	@ResponseStatus(code = HttpStatus.NOT_ACCEPTABLE)
	public String invalidDateException(Exception ue) {
		logger.error(errMsg, ue.getMessage());
		return errMsg + ue.getMessage();
	}

}
