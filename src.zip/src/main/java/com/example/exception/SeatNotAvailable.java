package com.example.exception;

public class SeatNotAvailable extends Exception{

	public SeatNotAvailable(String msg) {
		super(msg);
	}
}
