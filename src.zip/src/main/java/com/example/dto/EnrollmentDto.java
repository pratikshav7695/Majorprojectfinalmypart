package com.example.dto;

import java.sql.Date;
import java.time.LocalTime;

import com.example.entity.EnrollmentStatus;



public class EnrollmentDto {	
	private Integer enrollmentId;	
	private Integer userId;
	private String userName;
	private String userEmail;
	private String userPassword;	
	private String userPhone;
	private String userAddress;
	private String userBloodGroup;	
	//private int failedLoginCounts;
	private Integer batchId;
	private String batchName;
	private LocalTime batchStartTime;
	private LocalTime batchEndTime;
	private int batchSize;
	private int batchRemainingSeats;
	private Integer offerId;
	private String offerName;
	private int offerDuration;
	private int offerDiscount;
	private int likesOnOffer;
	private Integer sportId;
	private String sportName;
	private double sportFees;	
	private Date enrollmentStartDate;	
	private Date enrollmentEndDate;	
	private double enrollmentPayableFees;	
	private EnrollmentStatus enrollmentStatus;
	
	public EnrollmentDto() {
		super();
	}

	public EnrollmentDto(Integer enrollmentId, Integer userId, String userName, String userEmail, String userPassword,
			String userPhone, String userAddress, String userBloodGroup, Integer batchId, String batchName,
			LocalTime batchStartTime, LocalTime batchEndTime, int batchSize, int batchRemainingSeats, Integer offerId,
			String offerName, int offerDuration, int offerDiscount, int likesOnOffer, Integer sportId, String sportName,
			double sportFees, Date enrollmentStartDate, Date enrollmentEndDate, double enrollmentPayableFees,
			EnrollmentStatus enrollmentStatus) {
		super();
		this.enrollmentId = enrollmentId;
		this.userId = userId;
		this.userName = userName;
		this.userEmail = userEmail;
		this.userPassword = userPassword;
		this.userPhone = userPhone;
		this.userAddress = userAddress;
		this.userBloodGroup = userBloodGroup;
		this.batchId = batchId;
		this.batchName = batchName;
		this.batchStartTime = batchStartTime;
		this.batchEndTime = batchEndTime;
		this.batchSize = batchSize;
		this.batchRemainingSeats = batchRemainingSeats;
		this.offerId = offerId;
		this.offerName = offerName;
		this.offerDuration = offerDuration;
		this.offerDiscount = offerDiscount;
		this.likesOnOffer = likesOnOffer;
		this.sportId = sportId;
		this.sportName = sportName;
		this.sportFees = sportFees;
		this.enrollmentStartDate = enrollmentStartDate;
		this.enrollmentEndDate = enrollmentEndDate;
		this.enrollmentPayableFees = enrollmentPayableFees;
		this.enrollmentStatus = enrollmentStatus;
	}

	public Integer getEnrollmentId() {
		return enrollmentId;
	}

	public void setEnrollmentId(Integer enrollmentId) {
		this.enrollmentId = enrollmentId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getUserPhone() {
		return userPhone;
	}

	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}

	public String getUserAddress() {
		return userAddress;
	}

	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}

	public String getUserBloodGroup() {
		return userBloodGroup;
	}

	public void setUserBloodGroup(String userBloodGroup) {
		this.userBloodGroup = userBloodGroup;
	}

	public Integer getBatchId() {
		return batchId;
	}

	public void setBatchId(Integer batchId) {
		this.batchId = batchId;
	}

	public String getBatchName() {
		return batchName;
	}

	public void setBatchName(String batchName) {
		this.batchName = batchName;
	}

	public LocalTime getBatchStartTime() {
		return batchStartTime;
	}

	public void setBatchStartTime(LocalTime batchStartTime) {
		this.batchStartTime = batchStartTime;
	}

	public LocalTime getBatchEndTime() {
		return batchEndTime;
	}

	public void setBatchEndTime(LocalTime batchEndTime) {
		this.batchEndTime = batchEndTime;
	}

	public int getBatchSize() {
		return batchSize;
	}

	public void setBatchSize(int batchSize) {
		this.batchSize = batchSize;
	}

	public int getBatchRemainingSeats() {
		return batchRemainingSeats;
	}

	public void setBatchRemainingSeats(int batchRemainingSeats) {
		this.batchRemainingSeats = batchRemainingSeats;
	}

	public Integer getOfferId() {
		return offerId;
	}

	public void setOfferId(Integer offerId) {
		this.offerId = offerId;
	}

	public String getOfferName() {
		return offerName;
	}

	public void setOfferName(String offerName) {
		this.offerName = offerName;
	}

	public int getOfferDuration() {
		return offerDuration;
	}

	public void setOfferDuration(int offerDuration) {
		this.offerDuration = offerDuration;
	}

	public int getOfferDiscount() {
		return offerDiscount;
	}

	public void setOfferDiscount(int offerDiscount) {
		this.offerDiscount = offerDiscount;
	}

	public int getLikesOnOffer() {
		return likesOnOffer;
	}

	public void setLikesOnOffer(int likesOnOffer) {
		this.likesOnOffer = likesOnOffer;
	}

	public Integer getSportId() {
		return sportId;
	}

	public void setSportId(Integer sportId) {
		this.sportId = sportId;
	}

	public String getSportName() {
		return sportName;
	}

	public void setSportName(String sportName) {
		this.sportName = sportName;
	}

	public double getSportFees() {
		return sportFees;
	}

	public void setSportFees(double sportFees) {
		this.sportFees = sportFees;
	}

	public Date getEnrollmentStartDate() {
		return enrollmentStartDate;
	}

	public void setEnrollmentStartDate(Date enrollmentStartDate) {
		this.enrollmentStartDate = enrollmentStartDate;
	}

	public Date getEnrollmentEndDate() {
		return enrollmentEndDate;
	}

	public void setEnrollmentEndDate(Date enrollmentEndDate) {
		this.enrollmentEndDate = enrollmentEndDate;
	}

	public double getEnrollmentPayableFees() {
		return enrollmentPayableFees;
	}

	public void setEnrollmentPayableFees(double enrollmentPayableFees) {
		this.enrollmentPayableFees = enrollmentPayableFees;
	}

	public EnrollmentStatus getEnrollmentStatus() {
		return enrollmentStatus;
	}

	public void setEnrollmentStatus(EnrollmentStatus enrollmentStatus) {
		this.enrollmentStatus = enrollmentStatus;
	}

	@Override
	public String toString() {
		return "EnrollmentData [enrollmentId=" + enrollmentId + ", userId=" + userId + ", userName=" + userName
				+ ", userEmail=" + userEmail + ", userPassword=" + userPassword + ", userPhone=" + userPhone
				+ ", userAddress=" + userAddress + ", userBloodGroup=" + userBloodGroup + ", batchId=" + batchId
				+ ", batchName=" + batchName + ", batchStartTime=" + batchStartTime + ", batchEndTime=" + batchEndTime
				+ ", batchSize=" + batchSize + ", batchRemainingSeats=" + batchRemainingSeats + ", offerId=" + offerId
				+ ", offerName=" + offerName + ", offerDuration=" + offerDuration + ", offerDiscount=" + offerDiscount
				+ ", likesOnOffer=" + likesOnOffer + ", sportId=" + sportId + ", sportName=" + sportName
				+ ", sportFees=" + sportFees + ", enrollmentStartDate=" + enrollmentStartDate + ", enrollmentEndDate="
				+ enrollmentEndDate + ", enrollmentPayableFees=" + enrollmentPayableFees + ", enrollmentStatus="
				+ enrollmentStatus + "]";
	}
	
	
}
