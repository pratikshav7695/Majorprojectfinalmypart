package com.example.dto;

public class ForgetPasswordDto {
private String userEmail;
private String newPassword;
private long otp;
public ForgetPasswordDto() {
	super();
}
public ForgetPasswordDto(String userEmail, long otp,String newPassword) {
	super();
	this.userEmail = userEmail;
	this.otp = otp;
	this.newPassword = newPassword;
}


public ForgetPasswordDto(String userEmail, String newPassword) {
	super();
	this.userEmail = userEmail;
	this.newPassword = newPassword;
}
public ForgetPasswordDto(long otp) {
	super();
	this.otp = otp;
}
public String getNewPassword() {
	return newPassword;
}
public void setNewPassword(String newPassword) {
	this.newPassword = newPassword;
}
public String getUserEmail() {
	return userEmail;
}
public void setUserEmail(String userEmail) {
	this.userEmail = userEmail;
}
public long getOtp() {
	return otp;
}
public void setOtp(long otp) {
	this.otp = otp;
}
@Override
public String toString() {
	return "ForgetPasswordDto [userEmail=" + userEmail + ", newPassword=" + newPassword + ", otp=" + otp + "]";
}


}
